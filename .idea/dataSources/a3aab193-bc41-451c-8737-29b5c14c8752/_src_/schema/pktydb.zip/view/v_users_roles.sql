CREATE VIEW v_users_roles AS
  SELECT
    `u`.`user_name` AS `user_name`,
    `r`.`role_name` AS `role_name`
  FROM ((`pktydb`.`users` `u`
    JOIN `pktydb`.`users_roles` `ur` ON ((`u`.`id` = `ur`.`user_id`))) JOIN `pktydb`.`roles` `r`
      ON ((`r`.`id` = `ur`.`role_id`)));
